window.addEventListener("gamepadconnected", () => {
  console.log("Gamepad connected!");
  requestAnimationFrame(updateGamepad);
});

function updateGamepad() {
  const gamepads = navigator.getGamepads();
  if (!gamepads) {
    requestAnimationFrame(updateGamepad);
    return;
  }
  const gp = gamepads[0]; // assuming one gamepad
  if (!gp) {
    requestAnimationFrame(updateGamepad);
    return;
  }

  // Suppose Z = button 0, X = button 1, C = button 2
  const buttonMap = { 0: "Z", 1: "X", 2: "C" };

  gp.buttons.forEach((btn, index) => {
    if (btn.pressed && buttonMap[index]) {
      console.log(buttonMap[index] + " pressed");
      // You can also update your UI here
    }
  });

  requestAnimationFrame(updateGamepad);
}
